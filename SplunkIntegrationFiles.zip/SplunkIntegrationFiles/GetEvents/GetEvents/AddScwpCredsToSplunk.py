#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import getpass
sys.path.append('../')
import splunklib.client as client

scwpApiKeysRealm = "ScwpApiKeyCreds"
splunkServer = raw_input("Enter Splunk server name/IP [localhost]: ") or "localhost"
splunkAdmin = raw_input("Enter admin user name [admin]: ") or "admin"
splunkPassword = getpass.getpass()
overwrite = "n"

splunkService = client.connect(host=splunkServer, port=8089, username=splunkAdmin, password=splunkPassword)
 
storage_passwords = splunkService.storage_passwords
current_credentials = [k for k in storage_passwords if k.content.get('realm')==scwpApiKeysRealm]
if len(current_credentials) == 0:
    print("No existing SCWP credentials found.")
else:
    print("Currently stored SCWP credentials: ")
    for current_credential in current_credentials:
        usercreds = {'clientId':current_credential.content.get('username'), 'clientSecretKey':current_credential.content.get('clear_password')}
        print usercreds

    overwrite = raw_input("Do you want to overwrite? (y/n)[y]: ") or "y"
    if overwrite != "y":
        sys.exit()

scwpClientId = raw_input("Enter SCWP Client ID: ")
scwpClientSecret = raw_input("Enter SCWP Client Secret: ")
if overwrite == "y":
    for current_credential in current_credentials:
        splunkService.storage_passwords.delete(current_credential.content.get('username'), scwpApiKeysRealm)
storage_password = splunkService.storage_passwords.create(scwpClientSecret, scwpClientId, scwpApiKeysRealm)
print("Stored credentials with name: " + storage_password.name)

